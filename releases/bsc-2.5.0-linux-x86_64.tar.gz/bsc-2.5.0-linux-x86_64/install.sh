#!/bin/bash
# =================================================================================================
# BSC (Bank Statement Conversion) - Instalador Local para Linux
# Desenvolvido por Matheus Sousa, Laboratório de Comunicação e Segurança da Informação,
# Departamento de Eletrônica e Sistemas, CTG-UFPE.
# =================================================================================================
set -e

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BIN_DIR="$HOME/.local/bin"
APP_DIR="$HOME/.local/share/applications"
ICON_DIR="$HOME/.local/share/icons/hicolor/scalable/apps"

mkdir -p "$BIN_DIR" "$APP_DIR" "$ICON_DIR"

echo "Instalando BSC em $BIN_DIR..."
install -m 755 "$DIR/BSC" "$BIN_DIR/BSC"
install -m 644 "$DIR/bsc.svg" "$ICON_DIR/bsc.svg"

sed -e "s|^Exec=BSC|Exec=$BIN_DIR/BSC|" \
    -e "s|^Icon=bsc|Icon=$ICON_DIR/bsc.svg|" \
    "$DIR/bsc.desktop" > "$APP_DIR/bsc.desktop"

chmod +x "$APP_DIR/bsc.desktop"

echo "Instalacao concluida com sucesso!"
echo "Voce pode iniciar o BSC pelo menu de aplicativos ou executando 'BSC' no terminal."
