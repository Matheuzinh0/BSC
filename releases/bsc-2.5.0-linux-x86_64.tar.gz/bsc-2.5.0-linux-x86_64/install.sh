#!/bin/bash
set -e
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BIN_DIR="$HOME/.local/bin"
APP_DIR="$HOME/.local/share/applications"
ICON_DIR="$HOME/.local/share/icons/hicolor/scalable/apps"

mkdir -p "$BIN_DIR" "$APP_DIR" "$ICON_DIR"
install -m 755 "$DIR/BSC" "$BIN_DIR/BSC"
install -m 644 "$DIR/bsc.svg" "$ICON_DIR/bsc.svg"

sed -e "s|^Exec=BSC|Exec=$BIN_DIR/BSC|" \
    -e "s|^Icon=bsc|Icon=$ICON_DIR/bsc.svg|" \
    "$DIR/bsc.desktop" > "$APP_DIR/bsc.desktop"
chmod +x "$APP_DIR/bsc.desktop"

echo "Instalacao concluida com sucesso em $BIN_DIR/BSC!"
