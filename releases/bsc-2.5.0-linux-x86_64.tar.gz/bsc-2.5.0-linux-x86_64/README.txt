=================================================================================
BSC - Bank Statement Conversion (Versao 2.5.0)
Desenvolvido por Matheus Sousa, Laboratorio de Comunicacao e Seguranca da Informacao,
Departamento de Eletronica e Sistemas, CTG-UFPE.
=================================================================================

EXECUCAO DIRETA (SEM INSTALACAO):
    ./BSC

INSTALACAO OPCIONAL NO MENU DO SISTEMA:
    ./install.sh
=================================================================================
