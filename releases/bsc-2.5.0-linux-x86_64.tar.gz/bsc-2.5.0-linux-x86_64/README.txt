=================================================================================
BSC - Bank Statement Conversion (Versao 2.5.0)
Desenvolvido por Matheus Sousa, Laboratorio de Comunicacao e Seguranca da Informacao,
Departamento de Eletronica e Sistemas, CTG-UFPE.
=================================================================================

COMO EXECUTAR (PORTABILIDADE DIRETA):
Basta dar dois cliques no arquivo 'BSC' ou executa-lo via terminal na pasta:
    ./BSC

COMO INSTALAR NO SISTEMA (OPCIONAL):
Para integrar ao menu de aplicativos da sua distribuicao Linux:
    ./install.sh

MODO LINHA DE COMANDO (PROCESSAMENTO EM LOTE HEADLESS):
    ./BSC --batch extrato1.pdf extrato2.ofx --to xlsx,csv --out ./convertidos
=================================================================================
