=================================================================================
BSC - Bank Statement Conversion (Versao 2.5.0 para Windows x86 / x64)
Desenvolvido por Matheus Sousa, Laboratorio de Comunicacao e Seguranca da Informacao,
Departamento de Eletronica e Sistemas, CTG-UFPE.
=================================================================================

COMPATIBILIDADE:
- Windows 11, Windows 10, Windows 8.1, Windows 8, Windows 7 (32-bit e 64-bit).
- Binario nativo PE32 x86 totalmente estatico, sem necessidade de instalacao
  de DLLs adicionais, .NET Framework ou Java.

INSTRUCOES DE USO:

1. INTERFACE GRAFICA (GUI):
   Basta dar um duplo clique em "BSC.exe".
   A interface abrira diretamente, permitindo:
   - Arrastar e soltar (drag-and-drop) seus arquivos de extrato (PDF, OFX, CSV, XLSX, QIF);
   - Selecionar os formatos de destino desejados na matriz de conversao;
   - Iniciar o processamento em lote em paralelo;
   - Inspecionar transacoes, saldos e totais calculados em tempo real.

2. MODO LINHA DE COMANDO (BATCH HEADLESS VIA PROMPT DE COMANDO OU POWERSHELL):
   Exemplo de conversao de arquivos para XLSX e OFX:
       BSC.exe --batch extrato1.pdf extrato2.csv --to xlsx,ofx --out .\convertidos

SEGURANCA DA INFORMACAO:
Processamento 100% local e deterministico em memoria, sem transmissao de dados
para a nuvem. Auditado com integridade criptografica SHA-256.
=================================================================================
