=================================================================================
BSC - Bank Statement Conversion (Versao 2.5.0 para Windows x86 / x64)
Desenvolvido por Matheus Sousa, Laboratorio de Comunicacao e Seguranca da Informacao,
Departamento de Eletronica e Sistemas, CTG-UFPE.
=================================================================================

COMPATIBILIDADE:
- Windows 11, Windows 10, Windows 8.1, Windows 8, Windows 7 (32-bit e 64-bit).
- Binario nativo PE32 x86 100% estatico, sem necessidade de DLLs adicionais.

COMO USAR:
Basta dar dois cliques em "BSC.exe".
=================================================================================
